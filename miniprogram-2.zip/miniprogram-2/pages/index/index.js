Page({
    // 轮播图
    data: {
      "bnrUrl": [{
      "url": "../pic/pic_0.png"
      },{
      "url": "../pic/pic_1.png"
      },{
      "url": "../pic/pic_2.png"
      }
      ]
  },
  onLoad: function () {

  }
})